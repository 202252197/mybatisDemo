create function `++`(`++` int) returns int
BEGIN
	#Routine body goes here...

	RETURN 0+1;
END;

